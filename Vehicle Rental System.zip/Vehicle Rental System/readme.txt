Features Added

1. Users
	-> Viewing all the available vehicles
	-> Borrowing the vehicles
	-> Returning the vehicles
	-> Viewing Past Transactions


2. Admin
	-> Add new vehicle
	-> Modify Exiting Vehicle Details
	-> Search Vehicles
	-> Credit User with more deposit


Credentials
User
email : hari
password : 1234

Admin 
email : hari
password : 1234